<?php 
$host = "localhost";
$user = "guest";
$password = "guest";
$database = "toy_project";

$conn = mysqli_connect($host, $user, $password, $database);
?>