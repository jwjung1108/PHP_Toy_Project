<?php
session_start();

include '../../connect.php';


// 연결 성공 시, 여기에 작업을 수행할 수 있습니다.

// 게시물 ID 가져오기
$post_id = $_GET['number'];
$userid = $_SESSION['UserID'];

// Prepared Statements를 사용하여 SQL Injection 방지
// 게시글에 대한 사용자별 추천 여부 확인
$stmt = mysqli_prepare($conn,'SELECT * FROM r_post_likes WHERE userid = ? and post_id = ?');
mysqli_stmt_bind_param($stmt,'si', $userid, $post_id);
mysqli_stmt_execute( $stmt );
$result = mysqli_stmt_get_result($stmt);
$isLiked = mysqli_num_rows($result);
mysqli_stmt_close($stmt);

if (!$isLiked) {
    // 게시글에 대한 추천 기록 삽입
    $stmt = mysqli_prepare($conn,'INSERT into r_post_likes(post_id, userid,created) values( ?, ?,NOW())');
    mysqli_stmt_bind_param($stmt, 'is', $post_id, $userid);
    mysqli_stmt_execute( $stmt );
    mysqli_stmt_close($stmt);

    // 게시글 추천 수 업데이트
    $stmt = mysqli_prepare($conn,'UPDATE r_board set likes = likes + 1 where number = ?');
    mysqli_stmt_bind_param($stmt, 'i', $post_id);
    mysqli_stmt_execute( $stmt );
    mysqli_stmt_close($stmt);

    // 추천 받은 게시물 사용자 포인트 증가
    $stmt = mysqli_prepare($conn,'update users set point = point + 13 where id = (select userid from r_board where number = ?)');
    mysqli_stmt_bind_param($stmt, 'i', $post_id);
    mysqli_stmt_execute( $stmt );
    mysqli_stmt_close($stmt);

        // 추천 완료 메시지 출력
        ?>
    <script>
        alert("추천되었습니다.");
        location.href = "r_readBoard.php?number=<?php echo $post_id ?>";
    </script>
    <?php
} else {
    // 이미 추천한 경우 메시지 출력
    ?>
    <script>
        alert("이미 추천되었습니다.");
        location.href = "r_readBoard.php?number=<?php echo $post_id ?>";
    </script>
    <?php
}

// 데이터베이스 연결 종료
?>