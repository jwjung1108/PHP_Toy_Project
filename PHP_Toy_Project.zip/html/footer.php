<!-- Footer -->
<footer id="footer">
    <section class="split contact">
        <section class="alt">
            <h3>소개</h3>
            <p>안녕하세요! 저희 사이트는 학습을 즐겁고 효율적으로 할 수 있도록 도와주는 플랫폼입니다. 우리는 지식 공유와 협력을 통해 더 나은 학습 경험을 제공하고자 합니다. 이곳에서는 다양한 주제에
                관한 학습 자료를 공유하고, 질문을 하고 답변을 받을 수 있는 커뮤니티를 운영하고 있습니다. 또한 회원들끼리 지식을 공유하고 소통할 수 있는 다양한 기능을 제공합니다. 함께 학습하는
                즐거움을 느껴보세요!</p>
        </section>

    </section>
</footer>

<!-- Copyright -->
<div id="copyright">
    <ul>
        <li>&copy; 지원교</li>
    </ul>
</div>